// Kill-switch service worker.
// A stale service worker from an earlier project on this localhost origin was
// forcing the page into a reload loop. This replacement unregisters itself,
// clears any caches it left behind, and reloads each controlled tab once so
// nothing controls the origin afterwards. Safe to delete once browsers are clean.
self.addEventListener("install", () => self.skipWaiting());

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      try {
        const keys = await caches.keys();
        await Promise.all(keys.map((k) => caches.delete(k)));
      } catch {
        // ignore
      }
      await self.registration.unregister();
      const clients = await self.clients.matchAll({ type: "window" });
      clients.forEach((client) => client.navigate(client.url));
    })(),
  );
});
