﻿bl_info = {
    "name": "Farpy Render Delivery",
    "author": "Farpy",
    "version": (0, 4, 1),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > Farpy",
    "description": "Send .blend or existing .orbx render packages directly to Farpy",
    "category": "Render",
}

import bpy
import threading
import webbrowser
from pathlib import Path
from urllib.parse import quote, urljoin

try:
    import requests
    RequestConnectionError = requests.exceptions.ConnectionError
except Exception:
    requests = None
    RequestConnectionError = ConnectionError

FARPY_UPLOAD_URL = "https://farpy.com/#start"
FARPY_DEFAULT_API_BASE = "https://farpy.com/node/v1/web-render"
FARPY_SITE_BASE = "https://farpy.com"
FARPY_ACCOUNT_URL = f"{FARPY_SITE_BASE}/account"
FARPY_PRICING_URL = f"{FARPY_SITE_BASE}/pricing"
FARPY_DOCS_URL = f"{FARPY_SITE_BASE}/docs"

OCTANE_MISSING_MESSAGE = (
    "OctaneRender for Blender is not installed. Install the OTOY Blender plugin "
    "to export ORBX, or upload an existing .orbx on farpy.com."
)


def _main_thread(callback):
    if bpy.app.background:
        callback()
        return

    def runner():
        callback()
        return None
    bpy.app.timers.register(runner, first_interval=0.0)


def _props():
    return bpy.context.scene.farpy_props


def _set_status(text):
    def update():
        _props().farpy_status = text
    _main_thread(update)


def _format_bytes(size):
    try:
        size = float(size)
    except Exception:
        return "unknown size"
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            if unit == "B":
                return f"{int(size)} {unit}"
            return f"{size:.1f} {unit}"
        size /= 1024
    return "unknown size"


def _set_uploading(filepath, renderer, frame_count):
    path = Path(filepath)
    try:
        size_text = _format_bytes(path.stat().st_size)
    except Exception:
        size_text = "unknown size"

    def update():
        props = _props()
        props.is_uploading = True
        props.last_project_path = str(path)
        props.farpy_status = f"Sending package {path.name} ({size_text})"

    _main_thread(update)
    print(f"FARPY_UPLOAD_START renderer={renderer} frames={frame_count} file={path.name} size={size_text}")


def _finish_uploading():
    def update():
        _props().is_uploading = False
    _main_thread(update)


def _set_upload_result(job_id="", workspace_url="", status_url="", status="Queued"):
    def update():
        props = _props()
        props.last_job_id = job_id or props.last_job_id
        props.last_workspace_url = workspace_url or props.last_workspace_url
        props.last_status_url = status_url or props.last_status_url
        props.farpy_status = status
        if props.open_workspace_after_upload and props.last_workspace_url:
            webbrowser.open(props.last_workspace_url)
    _main_thread(update)


def _set_delivery_links(download_url="", receipt_url=""):
    def update():
        props = _props()
        props.last_download_url = download_url or props.last_download_url
        props.last_receipt_url = receipt_url or props.last_receipt_url
    _main_thread(update)


def _safe_error_body(response):
    try:
        text = response.text.strip()
    except Exception:
        return ""
    if not text:
        return ""
    lowered = text.lower()
    if "token" in lowered or "secret" in lowered or "authorization" in lowered:
        return ""
    return text[:300]


def _upload_error_message(response):
    status = getattr(response, "status_code", None)
    body = _safe_error_body(response)
    lowered = body.lower()
    if status in (401, 403):
        return "Please sign in to Farpy before sending a package."
    if status == 413:
        return "This package is too large for Farpy. Try a smaller scene first."
    if status == 400 and ("unsupported" in lowered or "file_type" in lowered or "extension" in lowered):
        return "Farpy supports Blender .blend packages and existing Octane .orbx packages."
    if body:
        return f"Farpy could not send this package. {body}"
    return "Farpy could not send this package. Check your connection and try again."


def _friendly_exception(prefix):
    return f"{prefix} Check your connection and try again."


def _api_url(api_base, path):
    base = (api_base or FARPY_DEFAULT_API_BASE).rstrip("/") + "/"
    return urljoin(base, path.lstrip("/"))


def _workspace_url(job_id, download_token="", receipt_token=""):
    if not job_id:
        return FARPY_UPLOAD_URL
    url = f"{FARPY_SITE_BASE}/workspace?job_id={quote(job_id)}"
    if download_token:
        url += f"&download_token={quote(download_token)}"
    if receipt_token:
        url += f"&receipt_token={quote(receipt_token)}"
    return url


def _headers(api_token):
    headers = {}
    token = (api_token or "").strip()
    if token:
        headers["Authorization"] = f"Bearer {token}"
        headers["x-farpy-api-key"] = token
    return headers


def _octane_ops_module():
    return getattr(getattr(bpy, "ops", None), "octane", None)


def _frame_data(scene):
    start = int(getattr(scene, "frame_start", 1) or 1)
    end = int(getattr(scene, "frame_end", start) or start)
    if end < start:
        end = start
    count = end - start + 1
    return start, end, count


def _normalize_status(raw):
    value = str(raw or "").strip().lower()
    if value == "complete":
        return "Ready"
    if value == "failed":
        return "Failed"
    if value == "running":
        return "Rendering"
    if value in {"packaging", "packaged"}:
        return "Packaging"
    if value in {"queued", "submitted", "priced", "checkout_created", "captured"}:
        return "Queued"
    return raw or "Queued"


def _parse_upload_response(payload, api_base):
    job_id = payload.get("job_id") or payload.get("job", {}).get("job_id") or ""
    download_token = payload.get("download_token") or payload.get("job", {}).get("download_token") or ""
    receipt_token = payload.get("receipt_token") or payload.get("job", {}).get("receipt_token") or ""
    workspace_url = (
        payload.get("workspace_url")
        or payload.get("workspace")
        or _workspace_url(job_id, download_token, receipt_token)
    )
    status_url = payload.get("status_url") or payload.get("job_url") or ""
    if not status_url and job_id:
        status_url = _api_url(api_base, f"jobs/{job_id}")
    return job_id, workspace_url, status_url


def _capture_delivery_links(payload):
    download_url = payload.get("download_url") or payload.get("downloadUrl") or ""
    receipt_url = payload.get("receipt_url") or payload.get("receiptUrl") or ""
    if download_url or receipt_url:
        _set_delivery_links(download_url, receipt_url)


def _poll_status_background(status_url, api_token):
    if not status_url:
        return
    if requests is None:
        _set_status("Farpy could not send this package. Python requests is missing.")
        return
    for _attempt in range(120):
        try:
            response = requests.get(
                status_url,
                headers=_headers(api_token),
                timeout=20,
            )
            if response.status_code >= 200 and response.status_code < 300:
                payload = response.json()
                _capture_delivery_links(payload)
                status = _normalize_status(payload.get("status") or payload.get("state"))
                _set_status(status)
                if status in {"Ready", "Failed"}:
                    return
            else:
                _set_status("Farpy could not refresh this package. Open your workspace to check delivery.")
                return
        except RequestConnectionError:
            _set_status("Farpy could not send this package. Check your connection and try again.")
            return
        except Exception:
            _set_status(_friendly_exception("Farpy could not refresh this package."))
            return
        threading.Event().wait(5)


def _upload_file_background(filepath, renderer, api_base, api_token, frame_start, frame_end, frame_count):
    path = Path(filepath)
    _set_uploading(path, renderer, frame_count)
    if requests is None:
        _set_status("Farpy could not send this package. Python requests is missing.")
        _finish_uploading()
        return
    try:
        with path.open("rb") as handle:
            files = {"file": (path.name, handle, "application/octet-stream")}
            data = {
                "renderer": renderer,
                "frame_start": str(frame_start),
                "frame_end": str(frame_end),
                "frame_count": str(frame_count),
            }
            response = requests.post(
                _api_url(api_base, "uploads/create"),
                files=files,
                data=data,
                headers=_headers(api_token),
                timeout=300,
            )
    except RequestConnectionError:
        _set_status("Farpy could not send this package. Check your connection and try again.")
        _finish_uploading()
        return
    except Exception:
        _set_status(_friendly_exception("Farpy could not send this package."))
        _finish_uploading()
        return

    if response.status_code < 200 or response.status_code >= 300:
        _set_status(_upload_error_message(response))
        _finish_uploading()
        return

    try:
        payload = response.json()
        _capture_delivery_links(payload)
    except Exception:
        _set_status("Farpy could not read the package response. Open the website and try again.")
        _finish_uploading()
        return

    job_id, workspace_url, status_url = _parse_upload_response(payload, api_base)
    if not job_id:
        _set_upload_result("", workspace_url or FARPY_UPLOAD_URL, status_url, "Package sent. Open Farpy to track delivery.")
        _finish_uploading()
        return

    _set_upload_result(job_id, workspace_url, status_url, "Package sent to Farpy. Open your workspace to track delivery.")
    _finish_uploading()


class FARPY_Props(bpy.types.PropertyGroup):
    api_base_url: bpy.props.StringProperty(
        name="Farpy API base URL",
        default=FARPY_DEFAULT_API_BASE,
        description="Farpy web-render API base URL",
    )
    api_token: bpy.props.StringProperty(
        name="Farpy access token",
        default="",
        subtype="PASSWORD",
        description="Optional advanced token. Most users should sign in on farpy.com and use Open Farpy.",
    )
    open_workspace_after_upload: bpy.props.BoolProperty(
        name="Open workspace after upload",
        default=True,
        description="Open the Farpy workspace page after a successful upload",
    )
    is_uploading: bpy.props.BoolProperty(
        name="Upload in progress",
        default=False,
    )
    last_project_path: bpy.props.StringProperty(
        name="Last project",
        default="",
    )
    farpy_status: bpy.props.StringProperty(
        name="Status",
        default="Not connected",
    )
    session_status: bpy.props.StringProperty(
        name="Connection",
        default="Not connected",
    )
    last_job_id: bpy.props.StringProperty(
        name="Last job ID",
        default="",
    )
    last_workspace_url: bpy.props.StringProperty(
        name="Last workspace URL",
        default="",
    )
    last_status_url: bpy.props.StringProperty(
        name="Last status URL",
        default="",
    )
    last_download_url: bpy.props.StringProperty(
        name="Last download URL",
        default="",
    )
    last_receipt_url: bpy.props.StringProperty(
        name="Last receipt URL",
        default="",
    )
    octane_existing_orbx_path: bpy.props.StringProperty(
        name="Existing ORBX",
        subtype="FILE_PATH",
        default="",
        description="Existing ORBX file to upload to Farpy",
    )


class FARPY_OT_render(bpy.types.Operator):
    bl_idname = "farpy.render"
    bl_label = "Send to Farpy"

    def execute(self, context):
        props = context.scene.farpy_props
        blend_path = bpy.data.filepath

        if props.is_uploading:
            self.report({"WARNING"}, "A Farpy upload is already in progress.")
            return {"CANCELLED"}

        if not blend_path:
            props.farpy_status = "Save this Blender file before sending it to Farpy."
            self.report({"ERROR"}, "Save this Blender file before sending it to Farpy.")
            return {"CANCELLED"}

        path = Path(blend_path)
        if path.suffix.lower() != ".blend":
            props.farpy_status = "Farpy supports Blender .blend packages from this button."
            self.report({"ERROR"}, "Save this scene as a .blend file before sending it to Farpy.")
            return {"CANCELLED"}

        if not path.exists():
            props.farpy_status = "Farpy could not find this .blend file. Save it and try again."
            self.report({"ERROR"}, "Farpy could not find this .blend file. Save it and try again.")
            return {"CANCELLED"}

        if not context.scene.camera:
            props.farpy_status = "Set a camera before sending this Blender package."
            self.report({"ERROR"}, "Set a camera before sending this Blender package.")
            return {"CANCELLED"}

        frame_start, frame_end, frame_count = _frame_data(context.scene)
        props.farpy_status = "Sending package"
        threading.Thread(
            target=_upload_file_background,
            args=(
                str(path),
                "blender",
                props.api_base_url,
                props.api_token,
                frame_start,
                frame_end,
                frame_count,
            ),
            daemon=True,
        ).start()

        self.report({"INFO"}, "Package sent to Farpy. Open your workspace to track delivery.")
        return {"FINISHED"}


class FARPY_OT_upload_existing_orbx(bpy.types.Operator):
    bl_idname = "farpy.upload_existing_orbx"
    bl_label = "Send Existing ORBX"
    bl_description = "Choose an existing ORBX package and send it to Farpy"

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    filter_glob: bpy.props.StringProperty(default="*.orbx", options={"HIDDEN"})

    def execute(self, context):
        props = context.scene.farpy_props
        target = Path(bpy.path.abspath(self.filepath or props.octane_existing_orbx_path))

        if props.is_uploading:
            self.report({"WARNING"}, "A Farpy upload is already in progress.")
            return {"CANCELLED"}

        if target.suffix.lower() != ".orbx":
            props.farpy_status = "Choose an existing .orbx package."
            self.report({"ERROR"}, "Choose an existing .orbx package before sending it to Farpy.")
            return {"CANCELLED"}
        if not target.exists():
            props.farpy_status = "Farpy could not find that ORBX package."
            self.report({"ERROR"}, "Farpy could not find that ORBX package.")
            return {"CANCELLED"}

        props.octane_existing_orbx_path = str(target)
        props.farpy_status = "Sending package"
        threading.Thread(
            target=_upload_file_background,
            args=(
                str(target),
                "octane",
                props.api_base_url,
                props.api_token,
                1,
                1,
                1,
            ),
            daemon=True,
        ).start()

        self.report({"INFO"}, "Package sent to Farpy. Open your workspace to track delivery.")
        return {"FINISHED"}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class FARPY_OT_open_workspace(bpy.types.Operator):
    bl_idname = "farpy.open_workspace"
    bl_label = "Open Workspace"

    def execute(self, context):
        props = context.scene.farpy_props
        webbrowser.open(props.last_workspace_url or FARPY_UPLOAD_URL)
        return {"FINISHED"}


class FARPY_OT_open_download(bpy.types.Operator):
    bl_idname = "farpy.open_download"
    bl_label = "Open Download"

    def execute(self, context):
        props = context.scene.farpy_props
        webbrowser.open(props.last_download_url or props.last_workspace_url or FARPY_UPLOAD_URL)
        return {"FINISHED"}


class FARPY_OT_open_receipt(bpy.types.Operator):
    bl_idname = "farpy.open_receipt"
    bl_label = "Open Delivery Receipt"

    def execute(self, context):
        props = context.scene.farpy_props
        webbrowser.open(props.last_receipt_url or props.last_workspace_url or FARPY_UPLOAD_URL)
        return {"FINISHED"}


class FARPY_OT_open_account(bpy.types.Operator):
    bl_idname = "farpy.open_account"
    bl_label = "View Account"

    def execute(self, context):
        webbrowser.open(FARPY_ACCOUNT_URL)
        return {"FINISHED"}


class FARPY_OT_open_pricing(bpy.types.Operator):
    bl_idname = "farpy.open_pricing"
    bl_label = "View Pricing"

    def execute(self, context):
        webbrowser.open(FARPY_PRICING_URL)
        return {"FINISHED"}


class FARPY_OT_open_docs(bpy.types.Operator):
    bl_idname = "farpy.open_docs"
    bl_label = "View Docs"

    def execute(self, context):
        webbrowser.open(FARPY_DOCS_URL)
        return {"FINISHED"}


class FARPY_OT_check_session(bpy.types.Operator):
    bl_idname = "farpy.check_session"
    bl_label = "Check Farpy Session"

    def execute(self, context):
        props = context.scene.farpy_props
        if requests is None:
            props.session_status = "Python requests is missing; use Open Farpy instead."
            self.report({"ERROR"}, "Python requests is missing; use Open Farpy instead.")
            return {"CANCELLED"}

        try:
            response = requests.get(
                _api_url(props.api_base_url, "wallet/balance"),
                headers=_headers(props.api_token),
                timeout=20,
            )
        except RequestConnectionError:
            props.session_status = "Could not reach Farpy. Check your connection."
            return {"CANCELLED"}
        except Exception:
            props.session_status = "Could not check Farpy sign-in. Check your connection and try again."
            return {"CANCELLED"}

        if response.status_code == 200:
            try:
                payload = response.json()
                cents = int(payload.get("balance_cents", 0))
                props.session_status = f"Signed in - balance ${cents / 100:.2f}"
            except Exception:
                props.session_status = "Signed in"
            return {"FINISHED"}

        if response.status_code == 401:
            props.session_status = "Please sign in to Farpy before sending a package."
            return {"FINISHED"}

        if response.status_code == 403:
            props.session_status = "Invalid Farpy access token. Open Account or clear the token."
            return {"FINISHED"}

        body = _safe_error_body(response)
        props.session_status = "Farpy could not check your account." + (f" {body}" if body else "")
        return {"CANCELLED"}


class FARPY_OT_poll_status(bpy.types.Operator):
    bl_idname = "farpy.poll_status"
    bl_label = "Refresh Status"

    def execute(self, context):
        props = context.scene.farpy_props
        if requests is None:
            props.farpy_status = "Farpy could not refresh this package. Python requests is missing."
            return {"CANCELLED"}
        if not props.last_status_url:
            self.report({"ERROR"}, "No package tracker link returned yet.")
            return {"CANCELLED"}

        try:
            response = requests.get(
                props.last_status_url,
                headers=_headers(props.api_token),
                timeout=20,
            )
        except RequestConnectionError:
            props.farpy_status = "Farpy could not refresh this package. Check your connection."
            return {"CANCELLED"}
        except Exception as exc:
            props.farpy_status = f"Farpy could not refresh this package: {exc}"
            return {"CANCELLED"}

        if response.status_code < 200 or response.status_code >= 300:
            body = _safe_error_body(response)
            props.farpy_status = "Farpy could not refresh this package." + (f" {body}" if body else "")
            return {"CANCELLED"}

        try:
            payload = response.json()
            _capture_delivery_links(payload)
        except Exception:
            props.farpy_status = "Farpy could not read this package status."
            return {"CANCELLED"}

        props.farpy_status = _normalize_status(payload.get("status") or payload.get("state"))
        if payload.get("job_id"):
            props.last_job_id = payload.get("job_id")
        return {"FINISHED"}


class FARPY_OT_browser_fallback(bpy.types.Operator):
    bl_idname = "farpy.browser_fallback"
    bl_label = "Open Farpy"

    def execute(self, context):
        webbrowser.open(FARPY_UPLOAD_URL)
        return {"FINISHED"}


class FARPY_PT_panel(bpy.types.Panel):
    bl_label = "Farpy Render Delivery"
    bl_idname = "FARPY_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Farpy"

    def draw(self, context):
        layout = self.layout
        props = context.scene.farpy_props
        frame_start, frame_end, frame_count = _frame_data(context.scene)

        welcome = layout.box()
        welcome.label(text="Welcome to Farpy Render Delivery")
        welcome.label(text="1. Connect account")
        welcome.label(text="2. Select .blend")
        welcome.label(text="3. Render")
        welcome.label(text="4. Download receipt")

        connection = layout.box()
        connection.label(text=f"Connection: {props.session_status}")
        conn_row = connection.row(align=True)
        conn_row.operator("farpy.check_session", text="Check connection")
        conn_row.operator("farpy.open_account", text="Open Account")

        support = layout.box()
        support.label(text="Blender .blend packages supported.")
        support.label(text="Existing Octane .orbx packages send as")
        support.label(text="1-frame still packages in public alpha.")
        support.label(text="Delivery receipt opens from your workspace.")

        pricing = layout.box()
        pricing.label(text=f"Frames: {frame_start}-{frame_end} ({frame_count})")
        pricing.label(text="Delivery speed is selected on Farpy.")
        pricing.label(text="Final price is shown before render starts on Farpy.")

        layout.separator()
        status_box = layout.box()
        status_box.label(text=f"Status: {props.farpy_status}")
        if props.is_uploading:
            status_box.label(text="Uploading. Blender stays usable.")
        elif props.farpy_status == "Queued":
            status_box.label(text="Queued. Open workspace to track delivery.")
        elif props.farpy_status == "Rendering":
            status_box.label(text="Rendering. No fake percentages shown.")
        elif props.farpy_status == "Packaging":
            status_box.label(text="Packaging your download.")
        elif props.farpy_status == "Ready":
            status_box.label(text="Package delivered.")
        elif props.farpy_status == "Failed":
            status_box.label(text="Farpy could not deliver this package. Try again or open workspace.")

        upload_col = layout.column(align=True)
        upload_col.enabled = not props.is_uploading
        upload_col.operator("farpy.render", text="Render")

        orbx_box = layout.box()
        orbx_box.label(text="Existing Octane package")
        orbx_box.operator("farpy.upload_existing_orbx", text="Send .orbx")

        row = layout.row(align=True)
        row.operator("farpy.poll_status", text="Refresh")
        row.operator("farpy.open_workspace", text="Open Workspace")
        done_row = layout.row(align=True)
        done_row.enabled = bool(props.last_workspace_url)
        done_row.operator("farpy.open_download", text="Open Download")
        done_row.operator("farpy.open_receipt", text="Open Receipt")

        retry_row = layout.row(align=True)
        retry_row.operator("farpy.render", text="Render another")
        retry_row.operator("farpy.browser_fallback", text="Open Farpy")

        link_row = layout.row(align=True)
        link_row.operator("farpy.open_account", text="Account")
        link_row.operator("farpy.open_pricing", text="View Pricing")
        link_row.operator("farpy.open_docs", text="View Docs")

        layout.separator()
        if props.last_project_path:
            layout.label(text=f"Last file: {Path(props.last_project_path).name}")
        if props.last_job_id:
            layout.label(text=f"Package: {props.last_job_id}")

        if not _octane_ops_module():
            box = layout.box()
            box.label(text="OctaneRender for Blender is not installed.")
            box.label(text="Install the OTOY Blender plugin to export ORBX,")
            box.label(text="or upload an existing .orbx on farpy.com.")

        settings = layout.box()
        settings.label(text="Advanced connection")
        settings.prop(props, "api_base_url")
        settings.prop(props, "api_token")
        settings.prop(props, "open_workspace_after_upload")


classes = (
    FARPY_Props,
    FARPY_OT_render,
    FARPY_OT_upload_existing_orbx,
    FARPY_OT_open_workspace,
    FARPY_OT_open_download,
    FARPY_OT_open_receipt,
    FARPY_OT_open_account,
    FARPY_OT_open_pricing,
    FARPY_OT_open_docs,
    FARPY_OT_check_session,
    FARPY_OT_poll_status,
    FARPY_OT_browser_fallback,
    FARPY_PT_panel,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.farpy_props = bpy.props.PointerProperty(type=FARPY_Props)


def unregister():
    if hasattr(bpy.types.Scene, "farpy_props"):
        del bpy.types.Scene.farpy_props
    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()

